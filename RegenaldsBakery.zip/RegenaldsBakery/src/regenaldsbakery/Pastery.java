/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package regenaldsbakery;

/**
 *
 * @author David
 */
public class Pastery extends Bakeryitem {//extending from the aprent class
     private String flavor;

   public Pastery(String name, double price,String flavor) {//constructor of the pastrey class
        super(name, price);
        this.flavor=flavor;
    }
   
   public String getFlavor() {
        return flavor;
    }
  

    @Override
    public String toString() {//@overide of the method in the parent class of the same name
        return super.toString() + " (Flavor: " + flavor + ")";
    }
    
}
