/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package regenaldsbakery;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author David
 */
public class RegenaldsBakery {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("Welcome to Regenalds Bakery");
        
        Scanner scanner = new Scanner(System.in);

        String customerName = getCustomerName(scanner);

        // Creating and displaying the menu
        ArrayList<Bakeryitem> bakeryItems = createMenu();
        displayMenu(bakeryItems);//calling the menu with the menu items

        // Take the user's order
        ArrayList<Integer> customerOrder = takeCustomerOrder(scanner, bakeryItems);//array list to save the customers order and input from customer

        // Display the receipt
        generateReceipt(customerName, customerOrder, bakeryItems);//calling the receipt class which will have the customers name order and items

        scanner.close();
        
       
    } 
    
    private static String getCustomerName(Scanner scanner) {//method for getting the customers name and order
        System.out.print("Enter your name: ");
        return scanner.nextLine();
    }
    
     public static ArrayList<Bakeryitem> createMenu() {//the menu of the bakery
        ArrayList<Bakeryitem> bakeryItems = new ArrayList<>();//an array list off bakery items
        bakeryItems.add(new Bread("Whole Wheat Bread", 3.99, "Whole Wheat"));
        bakeryItems.add(new Bread("French Baguette", 2.49, "White"));
        bakeryItems.add(new Pastery("Croissant", 2.99, "Butter"));
        bakeryItems.add(new Pastery("Chocolate Danish", 3.49, "Chocolate"));
        return bakeryItems;//here we are populating the bakeryitems array and returning what was captured
    }
     
     private static void displayMenu(ArrayList<Bakeryitem> bakeryItems) {
        System.out.println("Menu:");//this is the menu of the bakery after it has been populated
        for (int i = 0; i < bakeryItems.size(); i++) {
            System.out.println((i + 1) + ". " + bakeryItems.get(i));
        }
    }
     
      public static ArrayList<Integer> takeCustomerOrder(Scanner scanner, ArrayList<Bakeryitem> bakeryItems) {//here we are getting the customers order
        ArrayList<Integer> customerOrder = new ArrayList<>();//we have an array list that will keep the customers order in memory
        while (true) {
            System.out.print("Enter the item number you want to order (0 to finish): ");
            int choice = scanner.nextInt();
            if (choice == 0) {//ending order
                break;
            } else if (choice >= 1 && choice <= bakeryItems.size()) {//if choice is valid
                customerOrder.add(choice - 1);//adds the order to the array
            } else {
                System.out.println("Invalid choice. Please select a valid item.");//reprompts if input is invalid
            }
        }
        return customerOrder;
    }
      
       public static void generateReceipt(String customerName, ArrayList<Integer> customerOrder, ArrayList<Bakeryitem> bakeryItems) {//receipt method with both arrays being passed
        double totalCost = 0.0;//intializing cost
        System.out.println("\nReceipt for " + customerName + ":");
        for (int i : customerOrder) {//for the customers order
            Bakeryitem item = bakeryItems.get(i);//we get what was ordered
            System.out.println(item);
            totalCost += item.getPrice();//and we add that to the total cost
        }
        System.out.println("Total: R" + totalCost);
    }
}

//REFERNCES
//Smith, J.A. and Farrell, J. (2009) Java programs to accompany programming logic and Design. Boston, MA: Course Technology.
//https://www.geeksforgeeks.org/how-do-dynamic-arrays-work/
//https://www.javatpoint.com/java-do-while-loop
//https://www.programiz.com/java-programming/examples/pass-arraylist-as-function-argument
//https://www.tutorialspoint.com/java/util/scanner_close.htm#:~:text=close()%20method%20closes%20this,method%20will%20have%20no%20effect.
//https://www.scaler.com/topics/tostring-method-in-java/
