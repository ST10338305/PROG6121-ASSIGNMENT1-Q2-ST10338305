/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package regenaldsbakery;

import java.util.ArrayList;
import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author David
 */
public class RegenaldsBakeryTest {
    
    public RegenaldsBakeryTest() {
    }

    @Test
    public void testMain() {
    }
    
     @Test
    public void testCreateMenu() {
        ArrayList<Bakeryitem> menu = RegenaldsBakery.createMenu();
        assertNotNull(menu);
        assertTrue(menu.size() > 0); // Ensuring that the menu is not empty
    }
    
     @Test
    public void testTakeCustomerOrder() {
        Scanner scanner = new Scanner("1\n2\n0\n"); // Simulate user input
        ArrayList<Bakeryitem> menu = RegenaldsBakery.createMenu();
        ArrayList<Integer> order = RegenaldsBakery.takeCustomerOrder(scanner, menu);
        assertNotNull(order);
        assertTrue(order.size() > 0); // Ensuring that the order is not empty
    }
    
     @Test
    public void testGenerateReceipt() {
        ArrayList<Bakeryitem> menu = RegenaldsBakery.createMenu();
        ArrayList<Integer> order = new ArrayList<>();
        order.add(0);
        order.add(1);
        String customerName = "John";
        RegenaldsBakery.generateReceipt(customerName, order, menu);
      
    }

    
}
