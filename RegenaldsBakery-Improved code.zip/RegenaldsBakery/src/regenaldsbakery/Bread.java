/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package regenaldsbakery;

/**
 *
 * @author David
 */
public class Bread extends Bakeryitem {//extending from the parent class
    
    private String type;

    public Bread(String name, double price, String type) {//constructor for bread class
        super(name, price);
        this.type = type;
    }

    public String getType() {
        return type;
    }

    @Override//@overide of the method in the parent class of the same name
    public String toString() {
        return super.toString() + " (Type: " + type + ")";
    }
    
}
