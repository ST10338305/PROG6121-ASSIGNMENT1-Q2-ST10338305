/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package regenaldsbakery;

/**
 *
 * @author David
 */
public class Bakeryitem {
    
    private String name;
    private double price;

    public Bakeryitem(String name, double price) {//constructor for bakeryitem class
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {//this method will be overriden in our 2 child classes
        return name + " - R" + price;
    }
    
}
