/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package regenaldsbakery;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author David
 */
public class BakeryitemTest {
    
    public BakeryitemTest() {
    }

    @Test
    public void testGetName() {
    }

    @Test
    public void testGetPrice() {
    }

    @Test
    public void testToString() {
    }
    
    @Test
public void testBakeryItemGetName() {
    Bakeryitem item = new Bakeryitem("Test Item", 1.99);
    assertEquals("Test Item", item.getName());
}

@Test
public void testBakeryItemGetPrice() {
    Bakeryitem item = new Bakeryitem("Test Item", 1.99);
   assertEquals(1.99,item.getPrice(),0);
}
    
}
